package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.khieuware.datingapp.Models.UserModel;
import com.khieuware.datingapp.R;
import com.khieuware.datingapp.prefrence.SharedPrefManager;

public class MyPictures extends AppCompatActivity {

    RecyclerView recyclerView;
    LinearLayout btnChats,btnmatches;
    TextView txtName;
    String username;
    UserModel userModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_pictures);
        init();
    }

    private void init() {
        userModel= SharedPrefManager.getInstance(this).getUser();
        username= userModel.getName();

        txtName=findViewById(R.id.userName);
        txtName.setText("Welcome "+username);

        recyclerView=findViewById(R.id.recyclerView);
        btnChats=findViewById(R.id.btnChats);
        btnmatches=findViewById(R.id.btnMatch);
        btnChats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MyChats.class));

            }
        });
        btnmatches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), WeMatched.class));

            }
        });

    }
}