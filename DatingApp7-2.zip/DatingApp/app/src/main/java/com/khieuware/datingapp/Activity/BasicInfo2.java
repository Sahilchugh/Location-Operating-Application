package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.khieuware.datingapp.Adapters.SelectCountryRecycleAdapter1;
import com.khieuware.datingapp.Adapters.SexOrientRecycleAdapter;
import com.khieuware.datingapp.Extra.CustomVolleyJsonRequest;
import com.khieuware.datingapp.Extra.RecyclerTouchListener;
import com.khieuware.datingapp.Extra.Session_management;
import com.khieuware.datingapp.Models.OrientationFor;
import com.khieuware.datingapp.Models.SelectCountryModelClass;
import com.khieuware.datingapp.Models.UserModel;
import com.khieuware.datingapp.R;
import com.khieuware.datingapp.prefrence.SharedPrefManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.khieuware.datingapp.BaseUrl.KEY_ID;
import static com.khieuware.datingapp.BaseUrl.PROFILE_save;
import static com.khieuware.datingapp.BaseUrl.getSexData;
import static com.khieuware.datingapp.BaseUrl.uploadIMage;

public class BasicInfo2 extends AppCompatActivity {

    EditText etSkill, etHobby;
    TextView etsexData;
    LinearLayout btnSave,llorientaion,llAddphoto,llphoto,back;
    Dialog slideDialog;
    List<OrientationFor> selectCountryModelClasses1=new ArrayList<>();
    RecyclerView recyclerView1;
    ImageView cancel;
    SexOrientRecycleAdapter bAdapter1;
    String username,userAge,userHome,userCurrent,userEdu,stypeId,userID;

    FrameLayout frame1,farme2,frame3,frame4,frame5,frame6;
    ImageView image1,image2,image3,imag4,image5,imag6;

    private static final int  RESULT_LOAD_IMAGE = 1;
    private static final int  RESULT_LOAD_IMAGE2 = 2;
    private static final int  RESULT_LOAD_IMAGE3= 3;
    private static final int  RESULT_LOAD_IMAGE4= 4;
    private static final int  RESULT_LOAD_IMAGE5= 5;
    private static final int  RESULT_LOAD_IMAGE6= 6;
    Bitmap bitmap,bitmap2,bitmap3,bitmap4,bitmap5,bitmap6;
    Uri filePath,filePath2,filePath3,filePath4,filePath5,filePath6;
    String encodedImage,encodedImage2,encodedImage3,encodedImage4,encodedImage5,encodedImage6;

   // Session_management session_management;
    UserModel userModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_info2);
        init();
    }

    private void init() {
      //  session_management=new Session_management(this);
        userModel= SharedPrefManager.getInstance(this).getUser();
        userID= String.valueOf(userModel.getId());
        Log.d("dfg",userID);

        username=getIntent().getStringExtra("userName");
        userCurrent=getIntent().getStringExtra("curentCountry");
        userHome=getIntent().getStringExtra("homeCountry");
        userAge=getIntent().getStringExtra("userAge");
        userEdu=getIntent().getStringExtra("userEdu");

        etsexData=findViewById(R.id.etSexOrientation);
        etSkill=findViewById(R.id.etSkill);
        etHobby=findViewById(R.id.etHObby);
        llorientaion=findViewById(R.id.llOrientation);
        llAddphoto=findViewById(R.id.llAddPhoto);
        llphoto=findViewById(R.id.llphoto);
        btnSave=findViewById(R.id.btnSave);
        back=findViewById(R.id.back);

        frame1=findViewById(R.id.frame1);
        farme2=findViewById(R.id.frame2);
        frame3=findViewById(R.id.frame3);
        frame4=findViewById(R.id.frame4);
        frame5=findViewById(R.id.frame5);
        frame6=findViewById(R.id.frame6);

        image1=findViewById(R.id.image1);
        image2=findViewById(R.id.image2);
        image3=findViewById(R.id.image3);
        imag4=findViewById(R.id.image4);
        image5=findViewById(R.id.image5);
        imag6=findViewById(R.id.image6);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        llAddphoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llphoto.setVisibility(View.VISIBLE);
            }
        });
        frame1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser1();
            }
        });
        farme2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser2();
            }
        });

        frame3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser3();
            }
        });
        frame4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser4();
            }
        });

        frame5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser5();
            }
        });

        frame6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser6();
            }
        });


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etsexData.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Select Sex Orientation",Toast.LENGTH_SHORT).show();
                }else if(etSkill.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter your Skills",Toast.LENGTH_SHORT).show();
                }else if(etHobby.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter your Hobbies",Toast.LENGTH_SHORT).show();
                }else if (encodedImage==null) {
                    Toast.makeText(getApplicationContext(), "Please upload image!", Toast.LENGTH_SHORT).show();
                }else if (encodedImage2==null) {
                    Toast.makeText(getApplicationContext(), "Please upload at least 3 images!", Toast.LENGTH_SHORT).show();
                }else if (encodedImage3==null) {
                    Toast.makeText(getApplicationContext(), "Please upload at least 3 images!", Toast.LENGTH_SHORT).show();
                }else {
                    saveProfileUrl(userID);
                }
            }
        });

        llorientaion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataForSexOrientation();
            }
        });
    }

    private void dataForSexOrientation() {
        selectCountryModelClasses1.clear();
        String tag_json_obj = "json_category_req";
        Map<String, String> params = new HashMap<String, String>();

        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.GET,
                getSexData, params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("TAG", response.toString());

                try{

                    Boolean status = response.getBoolean("responce");
                    if (status)  {
                            Gson gson = new Gson();
                            Type listType = new TypeToken<List<OrientationFor>>() {
                            }.getType();
                            selectCountryModelClasses1 = gson.fromJson(response.getString("data"), listType);
                            bAdapter1 = new SexOrientRecycleAdapter(BasicInfo2.this,selectCountryModelClasses1);


                            slideDialog = new Dialog(BasicInfo2.this, R.style.CustomDialogAnimation);
                            slideDialog.setContentView(R.layout.select_sextype);


                            slideDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            // Setting dialogview
                            Window window = slideDialog.getWindow();
                            //  window.setGravity(Gravity.BOTTOM);

                            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

                            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                            slideDialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogAnimation;
                            layoutParams.copyFrom(slideDialog.getWindow().getAttributes());

                            int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.60);
                            int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.65);

                            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                            layoutParams.height = height;
                            layoutParams.gravity = Gravity.BOTTOM;

                            cancel= slideDialog.findViewById(R.id.cancel);
                            cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    slideDialog.dismiss();
                                }
                            });
                            recyclerView1 = slideDialog.findViewById(R.id.recyclerview);
                            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(BasicInfo2.this);
                            recyclerView1.setLayoutManager(layoutManager);
                            recyclerView1.setItemAnimator(new DefaultItemAnimator());

                            selectCountryModelClasses1 = new ArrayList<>();

                            for (int i = 0; i < selectCountryModelClasses1.size(); i++) {
                                OrientationFor mycreditList1= new OrientationFor(selectCountryModelClasses1.get(i).getId(),selectCountryModelClasses1.get(i).getOrientation());
                                selectCountryModelClasses1.add(mycreditList1);
                            }
                            recyclerView1.setAdapter(bAdapter1);
                          //  bAdapter1.notifyDataSetChanged();

                            slideDialog.getWindow().setAttributes(layoutParams);
                            slideDialog.setCancelable(true);
                            slideDialog.setCanceledOnTouchOutside(true);
                            slideDialog.show();
                        }
                    else {}

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("TAG", "Error: " + error.getMessage());
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                }
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(jsonObjReq);
    }

    public void selectedCountry(final String  id, final String name) {
         stypeId=id;
        etsexData.setText(name);
        slideDialog.dismiss();
    }
    private void showFileChooser1() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, RESULT_LOAD_IMAGE);
    }
    private void showFileChooser2() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, RESULT_LOAD_IMAGE2);
    }

    private void showFileChooser3() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, RESULT_LOAD_IMAGE3);
    }
    private void showFileChooser4() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, RESULT_LOAD_IMAGE4);
    }
    private void showFileChooser5() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, RESULT_LOAD_IMAGE5);
    }
    private void showFileChooser6() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, RESULT_LOAD_IMAGE6);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE) {
            if (resultCode == RESULT_OK) {
                filePath = data.getData();
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                    image1.setImageBitmap(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageBytes = baos.toByteArray();

                encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
                image1.setImageBitmap(bitmap);

                uploadPhotoUrl(userID,encodedImage);

                farme2.setVisibility(View.VISIBLE);
            } else if (resultCode == RESULT_CANCELED) {
                farme2.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            } else {
                farme2.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == RESULT_LOAD_IMAGE2) {
            if (resultCode == RESULT_OK) {
                filePath2 = data.getData();
                try {
                    bitmap2 = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath2);
                    image2.setImageBitmap(bitmap2);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap2.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageBytes = baos.toByteArray();

                encodedImage2 = Base64.encodeToString(imageBytes, Base64.DEFAULT);
                image2.setImageBitmap(bitmap2);
                uploadPhotoUrl(userID,encodedImage2);

                frame3.setVisibility(View.VISIBLE);
            } else if (resultCode == RESULT_CANCELED) {
                frame3.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            } else {
                frame3.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == RESULT_LOAD_IMAGE3) {
            if (resultCode == RESULT_OK) {
                filePath3 = data.getData();
                try {
                    bitmap3 = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath3);
                    image3.setImageBitmap(bitmap3);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap3.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageBytes = baos.toByteArray();

                encodedImage3 = Base64.encodeToString(imageBytes, Base64.DEFAULT);
                image3.setImageBitmap(bitmap3);
                uploadPhotoUrl(userID,encodedImage3);


                frame4.setVisibility(View.VISIBLE);
            } else if (resultCode == RESULT_CANCELED) {
                frame4.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            } else {
                frame4.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == RESULT_LOAD_IMAGE4) {
            if (resultCode == RESULT_OK) {
                filePath4 = data.getData();
                try {
                    bitmap4 = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath4);
                    imag4.setImageBitmap(bitmap4);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap4.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageBytes = baos.toByteArray();

                encodedImage4 = Base64.encodeToString(imageBytes, Base64.DEFAULT);
                imag4.setImageBitmap(bitmap4);
                uploadPhotoUrl(userID,encodedImage4);

                frame5.setVisibility(View.VISIBLE);
            } else if (resultCode == RESULT_CANCELED) {
                frame5.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            } else {
                frame5.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == RESULT_LOAD_IMAGE5) {
            if (resultCode == RESULT_OK) {
                filePath5 = data.getData();
                try {
                    bitmap5 = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath5);
                    image5.setImageBitmap(bitmap5);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap5.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageBytes = baos.toByteArray();

                encodedImage5 = Base64.encodeToString(imageBytes, Base64.DEFAULT);
                image5.setImageBitmap(bitmap5);
                uploadPhotoUrl(userID,encodedImage5);
                frame6.setVisibility(View.VISIBLE);
            } else if (resultCode == RESULT_CANCELED) {
                frame6.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            } else {
                frame6.setVisibility(View.GONE);
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == RESULT_LOAD_IMAGE6) {
            if (resultCode == RESULT_OK) {
                filePath6= data.getData();
                try {
                    bitmap6= MediaStore.Images.Media.getBitmap(getContentResolver(), filePath6);
                    imag6.setImageBitmap(bitmap6);

                } catch (IOException e) {
                    e.printStackTrace();
                }

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap6.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageBytes = baos.toByteArray();

                encodedImage6 = Base64.encodeToString(imageBytes, Base64.DEFAULT);
                imag6.setImageBitmap(bitmap6);
                uploadPhotoUrl(userID,encodedImage6);

            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            }
        }


    }

    private void uploadPhotoUrl(final String userId,final String encodedImage) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, uploadIMage, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("updateimageUrl",response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Boolean status = jsonObject.getBoolean("responce");
                    if (status){

                        Toast.makeText(getApplicationContext(),"Image uploaded successfully!",Toast.LENGTH_SHORT).show();

                    }else {
                        Toast.makeText(getApplicationContext(),"Please try again!",Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) { }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("user_id","5");
                param.put("image",encodedImage);

                Log.d("qwert",encodedImage);
                return param;
            }};

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

    private void saveProfileUrl(final String userId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, PROFILE_save, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("ProfileeUrl",response);
                //   progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Boolean status = jsonObject.getBoolean("responce");
                       String msg = jsonObject.getString("message");
                    if (status){
                        startActivity(new Intent(getApplicationContext(), MyPictures.class));

                        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
                    }
                    // progressDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // progressDialog.dismiss();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("user_id","5");
                param.put("name",username);
                param.put("age",userAge);
                param.put("education",userEdu);
                param.put("skills",etSkill.getText().toString());
                param.put("country",userCurrent);
                param.put("sexual_orientation_id",stypeId);
//
//                param.put("passion_id","NA");
//                param.put("gender","NA");
//                param.put("avatar","NA");
//                param.put("dob","NA");
//                param.put("show_gender","NA");
//                param.put("university","NA");
                return param;
            }};

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }
}