package com.khieuware.datingapp.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.khieuware.datingapp.Models.Image;
import com.khieuware.datingapp.Models.Titles;
import com.khieuware.datingapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class SimpleAdapter  extends RecyclerView.Adapter<SimpleAdapter.MyViewHolder>{

    Context context;
    private List<Titles> moviesList;

    public SimpleAdapter(List<Titles> imglist) {
        this.moviesList = imglist;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public MyViewHolder(View view) {
            super(view);
            title =  view.findViewById(R.id.title);
        }
    }

    @Override
    public SimpleAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_rounded, parent, false);

        return new SimpleAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(SimpleAdapter.MyViewHolder holder, int position) {
        Titles movie = moviesList.get(position);
        holder.title.setText(movie.getName());

    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}
