package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.khieuware.datingapp.Activity.HomePage;
import com.khieuware.datingapp.R;

public class Location extends AppCompatActivity {

    private static final int PERMISSIONS_CODE = 0;
    LinearLayout asklocation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        asklocation = findViewById(R.id.btn_getlocation);
        asklocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                checkpermission();

            }
        });
    }

    private void checkpermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            String[] permissions = new String[]{Manifest.permission.ACCESS_COARSE_LOCATION};
            ActivityCompat.requestPermissions(this, permissions, PERMISSIONS_CODE);
        }else {

            Intent intent = new Intent(this, HomePage.class);
            startActivity(intent);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                String permission = permissions[i];
                int grantResult = grantResults[i];

                if (permission.equals(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    if (grantResult == PackageManager.PERMISSION_GRANTED) {

                        Intent intent = new Intent(this, HomePage.class);
                        startActivity(intent);

                    } else {
                        checkpermission();
                    }
                }
            }
        }
    }
}