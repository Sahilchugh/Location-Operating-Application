package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.Volley;
import com.khieuware.datingapp.Activity.OtpCode;
import com.khieuware.datingapp.Extra.CustomVolleyJsonRequest;
import com.khieuware.datingapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.khieuware.datingapp.BaseUrl.SIGN_UP;
import static com.khieuware.datingapp.BaseUrl.SendOTP;

public class NewRegister extends AppCompatActivity {


    ProgressDialog progressDialog;
    TextView register,login;
    EditText etname,etemail,etpass,etphone;
    String emailpattern;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_register);
        inti();
    }

    private void inti() {
        emailpattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading..");
        progressDialog.setCancelable(true);
        register=findViewById(R.id.register);
        login=findViewById(R.id.login);

        etname=findViewById(R.id.input_Name);
        etemail=findViewById(R.id.input_emial);
        etphone=findViewById(R.id.input_Phoneh);
        etpass=findViewById(R.id.input_ConfPass);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etname.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Name",Toast.LENGTH_SHORT).show();
                }else if(etemail.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter E-mail",Toast.LENGTH_SHORT).show();
                }else if(!etemail.getText().toString().trim().matches(emailpattern)){
                    Toast.makeText(getApplicationContext(),"Enter valid E-mail",Toast.LENGTH_SHORT).show();
                }else if(etphone.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Mobile Number",Toast.LENGTH_SHORT).show();
                }else if(etphone.getText().toString().trim().length()<11){
                    Toast.makeText(getApplicationContext(),"Enter valid Mobile Number",Toast.LENGTH_SHORT).show();
                }else if(etpass.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Password",Toast.LENGTH_SHORT).show();
                }else {

                    registerUrl();

            }}
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),LoginwithPassword.class));
            }
        });
    }

    private void registerUrl() {
        String tag_json_obj = "json_register_req";
        Map<String, String> params = new HashMap<String, String>();
        params.put("name", etname.getText().toString());
        params.put("mobile", etphone.getText().toString());
        params.put("email", etemail.getText().toString());
        params.put("password", etpass.getText().toString());
//        params.put("lat", (lat!=null && lat.length()>0)?lat:"");
//        params.put("lon", (lng!=null && lng.length()>0)?lng:"");

        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.POST,
               SIGN_UP, params, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                Log.d("TAG", response.toString());

                try {
                    boolean status = response.getBoolean("responce");
                    if (status) {
                        progressDialog.dismiss();
                        String msg = response.getString("message");
                        Intent intent= new Intent(getApplicationContext(), OtpCode.class);
                        intent.putExtra("MobNo",etphone.getText().toString());
                        startActivity(intent);
                        finish();
                        Toast.makeText(getApplicationContext(), "" + msg, Toast.LENGTH_SHORT).show();

                        //otpSend();
//                        Intent i = new Intent(getApplicationContext(), OtpCode.class);
//                        i.putExtra("mobno",etphone.getText().toString());
//                        startActivity(i);
//                        finish();
                    } else {
                        progressDialog.dismiss();
                        register.setEnabled(true);
                        String error = response.getString("error");
                        Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("TAG", "Error: " + error.getMessage());
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                    register.setEnabled(true);
                    progressDialog.dismiss();
                   // Toast.makeText(SignUp.this, getResources().getString(R.string.connection_time_out), Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Adding request to request queue

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(jsonObjReq);

        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 5, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

    }

    private void otpSend() {
        progressDialog.show();
        Map<String, String> params = new HashMap<String, String>();
        params.put("mobile", etphone.getText().toString());
        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.POST,
                SendOTP, params, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                Log.d("TAG", response.toString());

                try {
                    boolean status = response.getBoolean("responce");
                    String msg = response.getString("message");

                    if (status) {
                        Toast.makeText(getApplicationContext(), "" + msg, Toast.LENGTH_SHORT).show();

                        Intent intent= new Intent(getApplicationContext(),OtpCode.class);
                        intent.putExtra("MobNo",etphone.getText().toString());
                        startActivity(intent);
                        finish();
                      //  Toast.makeText(getApplicationContext(), msg+"", Toast.LENGTH_SHORT).show();

                    }else {
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> params = new HashMap<>();
                params.put("mobile", etphone.getText().toString());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(jsonObjReq);

    }

}