package com.khieuware.datingapp.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.khieuware.datingapp.Adapters.SelectCountryRecycleAdapter;
import com.khieuware.datingapp.Adapters.SelectCountryRecycleAdapter1;
import com.khieuware.datingapp.Models.SelectCountryModelClass;
import com.khieuware.datingapp.R;

import java.util.ArrayList;

public class BasicInfo1 extends AppCompatActivity {

    EditText etName,etAge,etEdu;
    LinearLayout btnNext,llhome,llcurrentplace,bio;
    Dialog slideDialog;
    ArrayList<SelectCountryModelClass> selectCountryModelClasses;
    ArrayList<SelectCountryModelClass> selectCountryModelClasses1;
    RecyclerView recyclerView,recyclerView1;
    SelectCountryRecycleAdapter bAdapter;
    SelectCountryRecycleAdapter1 bAdapter1;
    ImageView imgC,imgH,userEdit;
    TextView txtC,txtH;
    private Integer image[] = {R.drawable.ic_india,R.drawable.ic_botswana,R.drawable.ic_canada,R.drawable.ic_mexico,R.drawable.ic_australia,R.drawable.ic_brazil,
            R.drawable.ic_russia};
    private String country_name[] = {"India","Botswana","Canada","Mexico","Australia","Brazil","Russia"};
    private String country_code[] = {"+91","+267","+1","+52","+61","+91","+43"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_info1);
        init();
    }

    private void init() {

        etName=findViewById(R.id.name);
        imgC=findViewById(R.id.image);
        txtC=findViewById(R.id.country_nameC);
        imgH=findViewById(R.id.imageH);
        txtH=findViewById(R.id.country_nameH);
        etAge=findViewById(R.id.etAge);
        etEdu=findViewById(R.id.etEdu);

        llhome=findViewById(R.id.llhome);
        llcurrentplace=findViewById(R.id.llresidence);
        bio=findViewById(R.id.bio);
        userEdit=findViewById(R.id.userEdit);

        bio.setVisibility(View.GONE);
        userEdit.setVisibility(View.GONE);

        btnNext=findViewById(R.id.btnnext);
        llcurrentplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                slideDialog = new Dialog(BasicInfo1.this, R.style.CustomDialogAnimation);
                slideDialog.setContentView(R.layout.select_country_popup);


                slideDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                // Setting dialogview
                Window window = slideDialog.getWindow();
                //  window.setGravity(Gravity.BOTTOM);

                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                slideDialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogAnimation;
                layoutParams.copyFrom(slideDialog.getWindow().getAttributes());

                int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.60);
                int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.65);

                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = height;
                layoutParams.gravity = Gravity.BOTTOM;


                recyclerView = slideDialog.findViewById(R.id.recyclerview);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(BasicInfo1.this);
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setItemAnimator(new DefaultItemAnimator());

                selectCountryModelClasses = new ArrayList<>();

                for (int i = 0; i < image.length; i++) {
                    SelectCountryModelClass mycreditList = new SelectCountryModelClass(image[i],country_name[i],country_code[i]);
                    selectCountryModelClasses.add(mycreditList);
                }
                bAdapter = new SelectCountryRecycleAdapter(BasicInfo1.this,selectCountryModelClasses);
                recyclerView.setAdapter(bAdapter);

                slideDialog.getWindow().setAttributes(layoutParams);
                slideDialog.setCancelable(true);
                slideDialog.setCanceledOnTouchOutside(true);
                slideDialog.show();
            }
        });
        llhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                slideDialog = new Dialog(BasicInfo1.this, R.style.CustomDialogAnimation);
                slideDialog.setContentView(R.layout.select_country_popup);


                slideDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                // Setting dialogview
                Window window = slideDialog.getWindow();
                //  window.setGravity(Gravity.BOTTOM);

                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                slideDialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogAnimation;
                layoutParams.copyFrom(slideDialog.getWindow().getAttributes());

                int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.60);
                int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.65);

                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = height;
                layoutParams.gravity = Gravity.BOTTOM;


                recyclerView1 = slideDialog.findViewById(R.id.recyclerview);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(BasicInfo1.this);
                recyclerView1.setLayoutManager(layoutManager);
                recyclerView1.setItemAnimator(new DefaultItemAnimator());

                selectCountryModelClasses1 = new ArrayList<>();

                for (int i = 0; i < image.length; i++) {
                    SelectCountryModelClass mycreditList1= new SelectCountryModelClass(image[i],country_name[i],country_code[i]);
                    selectCountryModelClasses1.add(mycreditList1);
                }
                bAdapter1 = new SelectCountryRecycleAdapter1(BasicInfo1.this,selectCountryModelClasses1);
                recyclerView1.setAdapter(bAdapter1);

                slideDialog.getWindow().setAttributes(layoutParams);
                slideDialog.setCancelable(true);
                slideDialog.setCanceledOnTouchOutside(true);
                slideDialog.show();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etName.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter User Name",Toast.LENGTH_SHORT).show();
                }else if(etAge.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter your Age",Toast.LENGTH_SHORT).show();
                }else if(etEdu.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter your Education",Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent=new Intent(getApplicationContext(),BasicInfo2.class);
                    intent.putExtra("userName",etName.getText().toString());
                    intent.putExtra("curentCountry",txtC.getText().toString());
                    intent.putExtra("homeCountry",txtH.getText().toString());
                    intent.putExtra("userAge",etAge.getText().toString());
                    intent.putExtra("userEdu",etEdu.getText().toString());
                    startActivity(intent);
                   // finish();
                }
            }
        });

    }
    public void selectedCountry(Integer image, String country_code) {
        imgC.setImageResource(image);
        txtC.setText(country_code);

        slideDialog.dismiss();
    }
    public void selectedCountry1(Integer image1, String country_code1) {
        imgH.setImageResource(image1);
        txtH.setText(country_code1);

        slideDialog.dismiss();
    }

}