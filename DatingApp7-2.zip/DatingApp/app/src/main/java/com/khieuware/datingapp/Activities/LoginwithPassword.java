package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.khieuware.datingapp.Extra.CustomVolleyJsonRequest;
import com.khieuware.datingapp.Extra.Session_management;
import com.khieuware.datingapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.khieuware.datingapp.BaseUrl.LOGIN;
import static com.khieuware.datingapp.BaseUrl.SendOTP;
import static com.khieuware.datingapp.BaseUrl.VERIFYOTP;

public class LoginwithPassword extends AppCompatActivity {


    TextView Login,forgotPass,SignUp;
    EditText emial,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginwith_password);
        init();
    }

    private void init() {
        emial= findViewById(R.id.input_emial);
        pass= findViewById(R.id.input_Password);
        Login= findViewById(R.id.login);
        forgotPass= findViewById(R.id.forPass);
        SignUp= findViewById(R.id.Signup);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(emial.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter User Id",Toast.LENGTH_SHORT).show();
                }else if(pass.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Password",Toast.LENGTH_SHORT).show();
                }else {
                    loginUrl();
                    Toast.makeText(getApplicationContext(),"Login successfully",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),Location.class));
                }
               //
            }
        });

        forgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),ForgotPassword.class));
            }
        });
        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),NewRegister.class));
            }
        });
    }

    private void loginUrl()  {

            String tag_json_obj = "json_login_req";
            Map<String, String> params = new HashMap<String, String>();
            params.put("userid",emial.getText().toString());
            params.put("password", pass.getText().toString());
//            params.put("social_login",type);
//            params.put("facebook_username",id);
        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.POST,
                LOGIN, params, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                Log.d("TAG", response.toString());

                try {
                    boolean status = response.getBoolean("responce");
                    String msg = response.getString("message");

                    if (status) {
                            JSONObject obj = response.getJSONObject("data");
                            String user_id = obj.getString("user_id");
                            String user_fullname = obj.getString("user_fullname");
                            String user_email = obj.getString("user_email");
                            String user_phone = obj.getString("user_phone");
                            String user_image = obj.getString("user_image");
                            String wallet_ammount = obj.getString("wallet");
                            String reward_points = obj.getString("rewards");

                            Session_management sessionManagement = new Session_management(getApplicationContext());
                            sessionManagement.createLoginSession(user_id, user_email, user_fullname, user_phone, user_image, wallet_ammount, reward_points, "", "", "", "", "");

//                        MyFirebaseRegister myFirebaseRegister = new MyFirebaseRegister(getApplicationContext());
//                        myFirebaseRegister.RegisterUser(user_id);
//                        btn_continue.setEnabled(false);
                            Intent i = new Intent(getApplicationContext(), Location.class);
                            //   i.putExtra("mobile", user_phone);
                            startActivity(i);
                            finish();

                        } else {

                         //   Toast.makeText(getApplicationContext(), "" , Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    } finally {
                      //  progressDialog.hide();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                  //  progressDialog.hide();
                    VolleyLog.d("TAG", "Error: " + error.getMessage());
                    if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                        //  Toast.makeText(getApplicationContext(), Login.this.getResources().getString(R.string.connection_time_out), Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // Adding request to request queue
            jsonObjReq.setRetryPolicy(new RetryPolicy() {
                @Override
                public int getCurrentTimeout() {
                    return 90000;
                }

                @Override
                public int getCurrentRetryCount() {
                    return 0;
                }

                @Override
                public void retry(VolleyError error) throws VolleyError {

                }
            });
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(jsonObjReq);
            // AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
        }


}