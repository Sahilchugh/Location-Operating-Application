package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.khieuware.datingapp.R;

public class SignUp extends AppCompatActivity {

    LinearLayout btnFb,btnGoogle,btnSignUp;
    EditText etname, etpassword,etConfirmPass,etMobile;
    TextView login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        init();
    }

    private void init() {
        etname=findViewById(R.id.etName);
        etMobile=findViewById(R.id.etMob);
        etpassword=findViewById(R.id.etPass);
        etConfirmPass=findViewById(R.id.etRePass);

        btnSignUp=findViewById(R.id.btnSignUp);
        login=findViewById(R.id.txtLogin);
        btnFb=findViewById(R.id.btnFb);
        btnGoogle=findViewById(R.id.btnGoogle);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etname.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter User Name",Toast.LENGTH_SHORT).show();
                }else if(etMobile.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Mobile No.",Toast.LENGTH_SHORT).show();
                }else if(etpassword.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Password",Toast.LENGTH_SHORT).show();
                }else if(etConfirmPass.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Re-type Password",Toast.LENGTH_SHORT).show();
                }else if(!etConfirmPass.getText().toString().trim().matches(etConfirmPass.getText().toString())){
                    Toast.makeText(getApplicationContext(),"Password mis-matched",Toast.LENGTH_SHORT).show();
                }else {
                    startActivity(new Intent(getApplicationContext(), BasicInfo1.class));
                    finish();
                    //  makeSignRequest(etname.getText().toString(), etMobile.getText().toString()etConfirmPass.getText().toString());
                }
            }
        });



    }
}