package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.khieuware.datingapp.Adapters.CenterZoomLayoutManager;
import com.khieuware.datingapp.Adapters.PremiumAdapter;
import com.khieuware.datingapp.Adapters.SliderImage;
import com.khieuware.datingapp.Models.Image;
import com.khieuware.datingapp.Models.premiumOffers;
import com.khieuware.datingapp.R;

import java.util.ArrayList;
import java.util.List;

public class PremiumPlan extends AppCompatActivity {

    LinearLayout back;
    RecyclerView recyclerView;
    PremiumAdapter adapter;
    List<premiumOffers> list=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_premium_plan);
        init();
    }

    private void init() {
        back=findViewById(R.id.back);
        recyclerView=findViewById(R.id.recyclerView);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        dummyData();
        recyclerView.setLayoutManager(new CenterZoomLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL,false));
        recyclerView.setAdapter(adapter);

    }
    private void dummyData() {
        premiumOffers cc=new premiumOffers("Gold","1","$123");
        list.add(cc);
        cc=new premiumOffers("Gold","1","$123");
        list.add(cc);
        cc=new premiumOffers("Gold","1","$123");
        list.add(cc);
        cc=new premiumOffers("Gold","1","$123");
        list.add(cc);
        cc=new premiumOffers("Gold","1","$123");
        list.add(cc);
        cc=new premiumOffers("Gold","1","$123");
        list.add(cc);

        adapter = new PremiumAdapter(list);
        adapter.notifyDataSetChanged();
    }

}