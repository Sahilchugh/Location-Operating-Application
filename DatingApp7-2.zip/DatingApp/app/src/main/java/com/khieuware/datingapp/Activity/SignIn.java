package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.khieuware.datingapp.Activities.LoginwithPassword;
import com.khieuware.datingapp.Activities.MainActivity;
import com.khieuware.datingapp.Activities.NewRegister;
import com.khieuware.datingapp.Extra.AppController;
import com.khieuware.datingapp.Extra.CustomVolleyJsonRequest;
import com.khieuware.datingapp.Extra.Session_management;
import com.khieuware.datingapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.khieuware.datingapp.BaseUrl.LOGIN;

public class SignIn extends AppCompatActivity {

    LinearLayout btnFb,btnGoogle,btnSignIn;
    EditText etname, etpassword;
    TextView regitser,Forgotpass;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        init();

    }

    private void init() {
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading..");
        progressDialog.setCancelable(true);

        regitser=findViewById(R.id.txtRegister);
      //  Forgotpass=findViewById(R.id.txtForgotpass);
        etname=findViewById(R.id.etName);
        etpassword=findViewById(R.id.etPass);
        btnFb=findViewById(R.id.btnFb);
        btnGoogle=findViewById(R.id.btnGoogle);
        btnSignIn=findViewById(R.id.btnSignIn);

        Forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ForgotPassword.class));

                finish();
            }
        });
        regitser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), SignUp.class));
                finish();

            }
        });


        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etname.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter User Name",Toast.LENGTH_SHORT).show();
                }else if(etpassword.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Password",Toast.LENGTH_SHORT).show();
                }else {
                  //makeLoginRequest(etname.getText().toString(),etpassword.getText().toString());

                    Intent i = new Intent(SignIn.this, HomePage.class);
                    startActivity(i);
                }
            }
        });
    }

    private void makeLoginRequest(String name, final String password) {

        // Tag used to cancel the request
        String tag_json_obj = "json_login_req";
        Map<String, String> params = new HashMap<String, String>();
        params.put("user_email", name);
        params.put("password", password);

        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.POST,
                LOGIN, params, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                Log.d("login", response.toString());

                try {
                    Boolean status = response.getBoolean("responce");
                    if (status) {
                        JSONObject obj = response.getJSONObject("data");
                        String user_id = obj.getString("user_id");
                        String user_fullname = obj.getString("user_fullname");
                        String user_email = obj.getString("user_email");
                        String user_phone = obj.getString("user_phone");
                        String user_image = obj.getString("user_image");
                        String wallet_ammount = obj.getString("wallet");
                        String reward_points = obj.getString("rewards");

                        Session_management sessionManagement = new Session_management(SignIn.this);
                        sessionManagement.createLoginSession(user_id, user_email, user_fullname, user_phone, user_image, wallet_ammount, reward_points, "", "", "", "", password);

                        progressDialog.dismiss();
                        Intent i = new Intent(SignIn.this, MainActivity.class);
                        startActivity(i);
                        finish();

                    } else {

                        progressDialog.dismiss();
                        String error = response.getString("error");
                        Toast.makeText(SignIn.this, "" + error, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("TAG", "Error: " + error.getMessage());
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                  //  Toast.makeText(Login.this, getResources().getString(R.string.connection_time_out), Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }
}