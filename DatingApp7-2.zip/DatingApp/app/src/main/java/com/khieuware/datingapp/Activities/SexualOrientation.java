package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.OrientationHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.khieuware.datingapp.Adapters.SimpleAdapter;
import com.khieuware.datingapp.Adapters.SliderImage;
import com.khieuware.datingapp.Models.Image;
import com.khieuware.datingapp.Models.Titles;
import com.khieuware.datingapp.R;

import java.util.ArrayList;
import java.util.List;

public class SexualOrientation extends AppCompatActivity {

    LinearLayout Continue;
    ImageView back;
    RecyclerView recyclerView;
    SimpleAdapter adapter;
    List<Titles> list=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sexual_orientation);
        init();
    }

    private void init() {

        dummyData();
        recyclerView=findViewById(R.id.recyclerview);

        StaggeredGridLayoutManager mLayoutManager = new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);
        mLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(adapter);
        Continue=findViewById(R.id.Continue);
        Continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),PassionOfUser.class));
            }
        });
    }

    private void dummyData() {
        Titles cc=new Titles("Straight");
        list.add(cc);
        cc=new Titles("Bi-sexual");
        list.add(cc);
        cc=new Titles("Homosexual");
        list.add(cc);
        cc=new Titles("Asexual");
        list.add(cc);
        cc=new Titles("Heterosexual");
        list.add(cc);
        cc=new Titles("Demisexual");
        list.add(cc);
        cc=new Titles("Allosexual");
        list.add(cc);
        cc=new Titles("Bicurious");
        list.add(cc);
        adapter = new SimpleAdapter(list);
        adapter.notifyDataSetChanged();
    }

}