package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.goodiebag.pinview.Pinview;
import com.khieuware.datingapp.Activities.BasicInformation;
import com.khieuware.datingapp.Activities.MainActivity;
import com.khieuware.datingapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.khieuware.datingapp.BaseUrl.VERIFYOTP;

public class OtpCode extends AppCompatActivity {

    LinearLayout Btncontinue;
    TextView resendCode;
    EditText etOtp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_code);
        init();
    }

    private void init() {
        etOtp=findViewById(R.id.etOtp);
        Btncontinue=findViewById(R.id.btnVerifyOtp);
        resendCode=findViewById(R.id.code);

        Btncontinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), BasicInfo1.class));
                finish();

            }
        });

    }
}