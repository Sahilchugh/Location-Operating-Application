package com.khieuware.datingapp.Models;

public class Image {
    int title;

    public Image(int image) {
        this.title=image;
    }

    public Integer getTitle() {
        return title;
    }

    public void setTitle(Integer title) {
        this.title = title;
    }
}
