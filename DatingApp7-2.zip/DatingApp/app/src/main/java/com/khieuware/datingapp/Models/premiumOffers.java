package com.khieuware.datingapp.Models;

public class premiumOffers {
    public premiumOffers(String gold, String mon, String mrp) {
        this.ptypes=gold;
        this.months=mon;
        this.price=mrp;
    }

    public String getPtypes() {
        return ptypes;
    }

    public void setPtypes(String ptypes) {
        this.ptypes = ptypes;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMonths() {
        return months;
    }

    public void setMonths(String months) {
        this.months = months;
    }

    String ptypes,price,months;
}
