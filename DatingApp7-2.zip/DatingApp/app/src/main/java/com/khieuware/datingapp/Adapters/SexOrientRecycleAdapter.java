package com.khieuware.datingapp.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.khieuware.datingapp.Activity.BasicInfo1;
import com.khieuware.datingapp.Activity.BasicInfo2;
import com.khieuware.datingapp.Activity.EditProfile;
import com.khieuware.datingapp.Models.OrientationFor;
import com.khieuware.datingapp.Models.SelectCountryModelClass;
import com.khieuware.datingapp.R;

import java.util.List;


public class SexOrientRecycleAdapter extends RecyclerView.Adapter<SexOrientRecycleAdapter.MyViewHolder> {

    Context context;


    private List<OrientationFor> OfferList;


    public class MyViewHolder extends RecyclerView.ViewHolder {


        ImageView image;
        TextView country_name, country_code;
        LinearLayout selectedCountry;


        public MyViewHolder(View view) {
            super(view);

            image = (ImageView) view.findViewById(R.id.image);
            country_name = (TextView) view.findViewById(R.id.country_name);
            country_code = (TextView) view.findViewById(R.id.country_code);
            selectedCountry = view.findViewById(R.id.selected_country);


        }

    }


    public SexOrientRecycleAdapter(Context context, List<OrientationFor> offerList) {
        this.OfferList = offerList;
        this.context = context;
    }

    @Override
    public SexOrientRecycleAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_select_coutnry_list, parent, false);


        return new SexOrientRecycleAdapter.MyViewHolder(itemView);


    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final OrientationFor lists = OfferList.get(position);
        holder.image.setVisibility(View.GONE);
        holder.country_name.setText(lists.getOrientation());
        holder.country_code.setVisibility(View.GONE);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (context instanceof BasicInfo2){
                    ((BasicInfo2)context).selectedCountry(lists.getId(),lists.getOrientation());
                }
                if (context instanceof EditProfile){
                    ((EditProfile)context).selectedCountry(lists.getId(),lists.getOrientation());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return OfferList.size();

    }

}


