package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.khieuware.datingapp.Fragments.HomeFragment;
import com.khieuware.datingapp.Fragments.ProfileFragment;
import com.khieuware.datingapp.R;

public class Settings extends AppCompatActivity {

    TextView notice,langauge,privacy,userProfile,location;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        intii();
    }

    private void intii() {

        notice=findViewById(R.id.notification);
        langauge=findViewById(R.id.languages);
        privacy=findViewById(R.id.privacy);
        userProfile=findViewById(R.id.userProfile);
        location=findViewById(R.id.location);

        notice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Notification.class));
            }
        });
        langauge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Languages.class));
            }
        });
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(new ProfileFragment());
             //   startActivity(new Intent(getApplicationContext(), ProfileFragment.class));
            }
        });
        userProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),LoginwithPassword.class));
            }
        });
        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Location.class));
            }
        });

    }
    private void loadFragment(Fragment fragment) {
        this.getSupportFragmentManager().beginTransaction()
                .replace(R.id.contentPanel, fragment)
                .commitAllowingStateLoss();
    }

}