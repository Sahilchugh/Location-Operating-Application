package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.khieuware.datingapp.R;

public class BasicInformation extends AppCompatActivity {

    ImageView back;
    EditText etname,etMob,etdate,etmonth,etyear,etedu,etgender,etBIrthPlace,etheiight,etAge,etZodiacsign,etjob;
    CheckBox checkBox;
    LinearLayout Continue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_information);
        init();
    }

    private void init() {
        checkBox=findViewById(R.id.checkbox);
        etname=findViewById(R.id.etNAme);
        etMob=findViewById(R.id.etMob);
        etdate=findViewById(R.id.date);
        etmonth=findViewById(R.id.month);

        etyear=findViewById(R.id.year);
        etedu=findViewById(R.id.etEdu);
        etgender=findViewById(R.id.etGender);
        etBIrthPlace=findViewById(R.id.etBirthPlace);

        etheiight=findViewById(R.id.etheight);
        etAge=findViewById(R.id.etAge);
        etZodiacsign=findViewById(R.id.etZodiacsign);
        etjob=findViewById(R.id.etjob);


        Continue=findViewById(R.id.Continue);
        Continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etname.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter your Name",Toast.LENGTH_SHORT).show();
                }else if(etMob.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Mobile Number",Toast.LENGTH_SHORT).show();
                }else if(etdate.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Birth date",Toast.LENGTH_SHORT).show();
                }else if(etmonth.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Birth month",Toast.LENGTH_SHORT).show();
                }else if(etyear.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Birth year",Toast.LENGTH_SHORT).show();
                }
                else if(etBIrthPlace.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Birth place",Toast.LENGTH_SHORT).show();
                }else if(etZodiacsign.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Zodiac Sign",Toast.LENGTH_SHORT).show();
                }else if(etgender.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter your Gender",Toast.LENGTH_SHORT).show();
                }else if(etheiight.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Height",Toast.LENGTH_SHORT).show();
                }else if(etAge.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Age",Toast.LENGTH_SHORT).show();
                }else if(etedu.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter your Education",Toast.LENGTH_SHORT).show();
                }else if(etjob.getText().toString().trim().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Enter Job details",Toast.LENGTH_SHORT).show();
                }else {
                    infoUrl();
                    startActivity(new Intent(getApplicationContext(),SexualOrientation.class));
                }

            }
        });
    }

    private void infoUrl() {
    }
}