package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.khieuware.datingapp.Adapters.CenterZoomLayoutManager;
import com.khieuware.datingapp.Adapters.SliderImage;
import com.khieuware.datingapp.Models.Image;
import com.khieuware.datingapp.R;

import java.util.ArrayList;
import java.util.List;

public class GetStarted extends AppCompatActivity {

    LinearLayout btnStart;
    RecyclerView recyclerView;
    SliderImage adapter;
    List<Image> imglist=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_started);
        init();
    }

    private void init() {
        btnStart=findViewById(R.id.btnStart);
        recyclerView=findViewById(R.id.recyclerview);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), SignIn.class));
                finish();

            }
        });
        dummyData();
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL,false));
        recyclerView.setAdapter(adapter);


    }
    private void dummyData() {
        Image cc=new Image(R.drawable.apple);
        imglist.add(cc);
        cc=new Image(R.drawable.apple);
        imglist.add(cc);
        cc=new Image(R.drawable.apple);
        imglist.add(cc);
        cc=new Image(R.drawable.apple);
        imglist.add(cc);
        cc=new Image(R.drawable.apple);
        imglist.add(cc);
        cc=new Image(R.drawable.apple);
        imglist.add(cc);

        adapter = new SliderImage(imglist);
        adapter.notifyDataSetChanged();
    }

}