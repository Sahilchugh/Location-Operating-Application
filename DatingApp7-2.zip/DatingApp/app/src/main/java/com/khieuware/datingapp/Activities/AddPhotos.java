package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.khieuware.datingapp.R;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class AddPhotos extends AppCompatActivity {

    LinearLayout Conntinuee;
    FrameLayout frame1,farme2,frame3,frame4,frame5,frame6;
    ImageView image1,image2,image3,imag4,image5,imag6;
    private static final int  RESULT_LOAD_IMAGE = 1;
    Bitmap bitmap;
    Uri filePath;
    String encodedImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_photos);
        inti();
    }

    private void inti() {

        frame1=findViewById(R.id.frame1);
        farme2=findViewById(R.id.frame2);
        frame3=findViewById(R.id.frame3);
        frame4=findViewById(R.id.frame4);
        frame5=findViewById(R.id.frame5);
        frame6=findViewById(R.id.frame6);

        image1=findViewById(R.id.image1);
        image2=findViewById(R.id.image2);
        image3=findViewById(R.id.image3);
        imag4=findViewById(R.id.image4);
        image5=findViewById(R.id.image5);
        imag6=findViewById(R.id.image6);

        frame1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                farme2.setFocusable(false);
                farme2.setClickable(false);

                showFileChooser1();


            }
        });
        farme2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser1();
            }
        });
        frame3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser1();
            }
        });
        Conntinuee=findViewById(R.id.Continue);
        Conntinuee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Location.class));
            }
        });

    }
    private void showFileChooser1() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, RESULT_LOAD_IMAGE);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE) {
            if (resultCode == RESULT_OK) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                image1.setImageBitmap(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] imageBytes = baos.toByteArray();

            encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
            image1.setImageBitmap(bitmap);
        } else if (resultCode == RESULT_CANCELED) {

                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, " Picture was not taken ", Toast.LENGTH_SHORT).show();
            }
        }
    }

}