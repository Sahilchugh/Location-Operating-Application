package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.khieuware.datingapp.Adapters.SelectCountryRecycleAdapter;
import com.khieuware.datingapp.Adapters.SexOrientRecycleAdapter;
import com.khieuware.datingapp.Extra.CustomVolleyJsonRequest;
import com.khieuware.datingapp.Models.OrientationFor;
import com.khieuware.datingapp.Models.SelectCountryModelClass;
import com.khieuware.datingapp.Models.UserModel;
import com.khieuware.datingapp.R;
import com.khieuware.datingapp.prefrence.SharedPrefManager;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.khieuware.datingapp.BaseUrl.BASEURL;
import static com.khieuware.datingapp.BaseUrl.getProfile;
import static com.khieuware.datingapp.BaseUrl.getSexData;

public class EditProfile extends AppCompatActivity {

    LinearLayout btnSave,back,llorientaion,llcurrentplace;
    TextView txtName,txtEmail;
    UserModel userModel;
    String username,userEmail;
    EditText etSkill, etHobby;
    TextView etsexData;
    ImageView imgC,proImg;
    TextView txtC;
    String stypeId;
    private Integer image[] = {R.drawable.ic_india,R.drawable.ic_botswana,R.drawable.ic_canada,R.drawable.ic_mexico,R.drawable.ic_australia,R.drawable.ic_brazil,
            R.drawable.ic_russia};
    private String country_name[] = {"India","Botswana","Canada","Mexico","Australia","Brazil","Russia"};
    private String country_code[] = {"+91","+267","+1","+52","+61","+91","+43"};
    Dialog slideDialog,slideDialog1;
    ArrayList<SelectCountryModelClass> selectCountryModelClasses;
    RecyclerView recyclerView;
    SelectCountryRecycleAdapter bAdapter;
    List<OrientationFor> selectCountryModelClasses1=new ArrayList<>();
    RecyclerView recyclerView1;
    SexOrientRecycleAdapter bAdapter1;
    ImageView cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        init();
    }

    private void init() {
        userModel= SharedPrefManager.getInstance(this).getUser();
        username= userModel.getName();
        userEmail= userModel.getEmail();

        txtName=findViewById(R.id.userName);
        txtEmail=findViewById(R.id.email);
        proImg=findViewById(R.id.imgeUser);
        back=findViewById(R.id.back);
        imgC=findViewById(R.id.image);
        txtC=findViewById(R.id.country_nameC);
        etsexData=findViewById(R.id.etSexOrientation);
        etSkill=findViewById(R.id.etSkill);
        etHobby=findViewById(R.id.etHObby);
        llorientaion=findViewById(R.id.llOrientation);
        llcurrentplace=findViewById(R.id.llresidence);
        btnSave=findViewById(R.id.btnnext);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        llorientaion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataForSexOrientation();
            }
        });
        llcurrentplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                slideDialog = new Dialog(EditProfile.this, R.style.CustomDialogAnimation);
                slideDialog.setContentView(R.layout.select_country_popup);


                slideDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                // Setting dialogview
                Window window = slideDialog.getWindow();
                //  window.setGravity(Gravity.BOTTOM);

                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                slideDialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogAnimation;
                layoutParams.copyFrom(slideDialog.getWindow().getAttributes());

                int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.60);
                int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.65);

                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                layoutParams.height = height;
                layoutParams.gravity = Gravity.BOTTOM;


                recyclerView = slideDialog.findViewById(R.id.recyclerview);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(EditProfile.this);
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setItemAnimator(new DefaultItemAnimator());

                selectCountryModelClasses = new ArrayList<>();

                for (int i = 0; i < image.length; i++) {
                    SelectCountryModelClass mycreditList = new SelectCountryModelClass(image[i],country_name[i],country_code[i]);
                    selectCountryModelClasses.add(mycreditList);
                }
                bAdapter = new SelectCountryRecycleAdapter(EditProfile.this,selectCountryModelClasses);
                recyclerView.setAdapter(bAdapter);

                slideDialog.getWindow().setAttributes(layoutParams);
                slideDialog.setCancelable(true);
                slideDialog.setCanceledOnTouchOutside(true);
                slideDialog.show();
            }
        });

        getProfileData(userModel.getId());
    }

    private void getProfileData(int id) {
        String tag_json_obj = "json_category_req";
        Map<String, String> params = new HashMap<String, String>();
        params.put("user_id", "5");
        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.POST,
                getProfile, params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("TAG", response.toString());

                try{

                    Boolean status = response.getBoolean("responce");
                    if (status)  {
                        JSONObject obj = response.getJSONObject("user_data");
                        String user_id = obj.getString("id");
                        String user_fullname = obj.getString("name");
                        String user_email = obj.getString("email");
                        String user_phone = obj.getString("mobile");
                        String user_image = obj.getString("avatar");
                        txtName.setText(user_fullname);
                        txtEmail.setText(user_email);
                        Picasso.get().load(BASEURL+user_image).into(proImg);
                    }
                    else {}

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("TAG", "Error: " + error.getMessage());
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                }
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(jsonObjReq);
    }

    public void selectedCountry(Integer image, String country_code) {
        imgC.setImageResource(image);
        txtC.setText(country_code);

        slideDialog.dismiss();
    }
    private void dataForSexOrientation() {
        selectCountryModelClasses1.clear();
        String tag_json_obj = "json_category_req";
        Map<String, String> params = new HashMap<String, String>();

        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.GET,
                getSexData, params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("TAG", response.toString());

                try{

                    Boolean status = response.getBoolean("responce");
                    if (status)  {
                        Gson gson = new Gson();
                        Type listType = new TypeToken<List<OrientationFor>>() {
                        }.getType();
                        selectCountryModelClasses1 = gson.fromJson(response.getString("data"), listType);
                        bAdapter1 = new SexOrientRecycleAdapter(EditProfile.this,selectCountryModelClasses1);


                        slideDialog = new Dialog(EditProfile.this, R.style.CustomDialogAnimation);
                        slideDialog.setContentView(R.layout.select_sextype);


                        slideDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        // Setting dialogview
                        Window window = slideDialog.getWindow();
                        //  window.setGravity(Gravity.BOTTOM);

                        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

                        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                        slideDialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogAnimation;
                        layoutParams.copyFrom(slideDialog.getWindow().getAttributes());

                        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.60);
                        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.65);

                        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                        layoutParams.height = height;
                        layoutParams.gravity = Gravity.BOTTOM;

                        cancel= slideDialog.findViewById(R.id.cancel);
                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                slideDialog.dismiss();
                            }
                        });
                        recyclerView1 = slideDialog.findViewById(R.id.recyclerview);
                        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(EditProfile.this);
                        recyclerView1.setLayoutManager(layoutManager);
                        recyclerView1.setItemAnimator(new DefaultItemAnimator());

                        selectCountryModelClasses1 = new ArrayList<>();

                        for (int i = 0; i < selectCountryModelClasses1.size(); i++) {
                            OrientationFor mycreditList1= new OrientationFor(selectCountryModelClasses1.get(i).getId(),selectCountryModelClasses1.get(i).getOrientation());
                            selectCountryModelClasses1.add(mycreditList1);
                        }
                        recyclerView1.setAdapter(bAdapter1);
                        //  bAdapter1.notifyDataSetChanged();

                        slideDialog.getWindow().setAttributes(layoutParams);
                        slideDialog.setCancelable(true);
                        slideDialog.setCanceledOnTouchOutside(true);
                        slideDialog.show();
                    }
                    else {}

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("TAG", "Error: " + error.getMessage());
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                }
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(jsonObjReq);
    }

    public void selectedCountry(final String  id, final String name) {
        stypeId=id;
        etsexData.setText(name);
        slideDialog.dismiss();
    }

}