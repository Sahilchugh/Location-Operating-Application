package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.khieuware.datingapp.Activity.OtpCode;
import com.khieuware.datingapp.R;

public class LoginWithPhone extends AppCompatActivity {

    TextView Next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_with_phone);
        init();
    }

    private void init() {
        Next=findViewById(R.id.Next);
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), OtpCode.class));
            }
        });
    }
}