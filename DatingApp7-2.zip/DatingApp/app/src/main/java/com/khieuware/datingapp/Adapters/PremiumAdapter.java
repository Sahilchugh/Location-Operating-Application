package com.khieuware.datingapp.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.khieuware.datingapp.Models.Image;
import com.khieuware.datingapp.Models.premiumOffers;
import com.khieuware.datingapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class PremiumAdapter extends RecyclerView.Adapter<PremiumAdapter.MyViewHolder> {

    Context context;
    private List<premiumOffers> moviesList;

    public PremiumAdapter(List<premiumOffers> imglist) {
        this.moviesList = imglist;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tpremiumtitle,tmonths,tprice;
        public MyViewHolder(View view) {
            super(view);
            tpremiumtitle =  view.findViewById(R.id.ptype);
            tmonths =  view.findViewById(R.id.totalmonth);
            tprice =  view.findViewById(R.id.price);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_premium_plans, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        premiumOffers movie = moviesList.get(position);
        holder.tpremiumtitle.setText(movie.getPtypes());
        holder.tmonths.setText(movie.getMonths());
        holder.tprice.setText(movie.getPrice());

    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}
