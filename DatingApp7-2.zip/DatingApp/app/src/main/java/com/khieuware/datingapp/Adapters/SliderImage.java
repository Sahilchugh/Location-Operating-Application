package com.khieuware.datingapp.Adapters;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.khieuware.datingapp.Models.Image;
import com.khieuware.datingapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class SliderImage extends RecyclerView.Adapter<SliderImage.MyViewHolder> {

    Context context;
    private List<Image> moviesList;

    public SliderImage(List<Image> imglist) {
        this.moviesList = imglist;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView title;
        public MyViewHolder(View view) {
            super(view);
            title =  view.findViewById(R.id.imge);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_images, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Image movie = moviesList.get(position);
        Picasso.get().load(movie.getTitle()).into(holder.title);
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}
