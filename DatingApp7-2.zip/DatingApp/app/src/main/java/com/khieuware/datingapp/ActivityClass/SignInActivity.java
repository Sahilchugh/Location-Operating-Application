package com.khieuware.datingapp.ActivityClass;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.khieuware.datingapp.Activities.Location;
import com.khieuware.datingapp.Activity.AppSettings;
import com.khieuware.datingapp.Activity.HomePage;
import com.khieuware.datingapp.BaseUrl;
import com.khieuware.datingapp.Fragments.ProfileFragment;
import com.khieuware.datingapp.Models.UserModel;
import com.khieuware.datingapp.R;
import com.khieuware.datingapp.prefrence.SharedPrefManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignInActivity extends AppCompatActivity {
    EditText etName, etPass;
    LinearLayout btnSignIn,btnSendOtp,btnFb,btnGoogle;
    TextView txtRegister;
    ProgressBar progressBar;
    UserModel model;
    String saveMobile;
    GoogleSignInClient mGoogleSignInClient;
    private static int RC_SIGN_IN=100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        progressBar = findViewById(R.id.progressBar);
        etName = findViewById(R.id.etName);
        etPass = findViewById(R.id.etPass);
        btnSignIn = findViewById(R.id.btnSignIn);
        btnSendOtp=findViewById(R.id.btnSendOtp);
        btnFb=findViewById(R.id.btnFb);
        btnGoogle=findViewById(R.id.btnGoogle);
        txtRegister = findViewById(R.id.txtRegister);
        model= SharedPrefManager.getInstance(this).getUser();
        saveMobile=model.getMobile();

        // Configure sign-in to request the user's ID, email address, and basic
// profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // Check for existing Google Sign In account, if the user is already signed in
// the GoogleSignInAccount will be non-null.
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);



        btnFb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        btnGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginWithGoogle();

            }
        });
        btnSendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SignInActivity.this,LoginWithMobileActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String  strUserId=etName.getText().toString();
                final String strPassword=etPass.getText().toString();
                if (TextUtils.isEmpty(strUserId)){
                    etName.setError("Please Enter Username");
                    etName.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(strPassword)){
                    etPass.setError("Please Enter Password");
                    etPass.requestFocus();
                    return;
                }
                StringRequest stringRequest=new StringRequest(Request.Method.POST, BaseUrl.LOGIN,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    progressBar.setVisibility(View.VISIBLE);
                                    JSONObject jsonObject=new JSONObject(response);
                                    Log.d("getResult",""+jsonObject);

                                    if (jsonObject.getBoolean("responce")){
                                JSONObject object=jsonObject.getJSONObject("data");
                                UserModel user=new UserModel(
                                        object.getInt("id"),
                                        object.getString("name"),
                                        object.getString("email"),
                                        object.getString("mobile"));

                                SharedPrefManager.getInstance(getApplicationContext()).userLogin(user);
                                finish();

                                        Toast.makeText(SignInActivity.this,jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                        Intent intent=new Intent(SignInActivity.this, Location.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                        progressBar.setVisibility(View.GONE);
                                    }else {
                                        progressBar.setVisibility(View.GONE);
                                        Toast.makeText(SignInActivity.this, "Please Enter Correct Username and Password", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SignInActivity.this,error.getMessage(), Toast.LENGTH_SHORT).show();


                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> params=new HashMap<>();
                        params.put("userid",strUserId);
                        params.put("password",strPassword);
                        return params;
                    }
                };
                RequestQueue requestQueue= Volley.newRequestQueue(SignInActivity.this);
                requestQueue.add(stringRequest);
            }

        });

        txtRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignInActivity.this, SignUpActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
        });


    }

    private void LoginWithGoogle() {

        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }
    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount((this));
            if (acct != null) {
                String personName = acct.getDisplayName();
                String personGivenName = acct.getGivenName();
                String personFamilyName = acct.getFamilyName();
                String personEmail = acct.getEmail();
                String personId = acct.getId();
                Uri personPhoto = acct.getPhotoUrl();
                //Toast.makeText(this, personEmail, Toast.LENGTH_SHORT).show();
            }
            Intent intent=new Intent(SignInActivity.this, HomePage.class);

            startActivity(intent);

            // Signed in successfully, show authenticated UI.
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.d("error",e.toString());

        }
    }


}