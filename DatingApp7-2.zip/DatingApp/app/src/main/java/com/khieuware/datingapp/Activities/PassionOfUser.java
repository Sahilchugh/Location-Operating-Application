package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.khieuware.datingapp.Adapters.SimpleAdapter;
import com.khieuware.datingapp.Models.Titles;
import com.khieuware.datingapp.R;

import java.util.ArrayList;
import java.util.List;

public class PassionOfUser extends AppCompatActivity {

    LinearLayout Continue;
    ImageView back;
    RecyclerView recyclerView;
    SimpleAdapter adapter;
    List<Titles> list=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passion_of_user);
        inti();
    }

    private void inti() {
        dummyData();
        recyclerView=findViewById(R.id.recyclerview);
        StaggeredGridLayoutManager mLayoutManager = new StaggeredGridLayoutManager(3,StaggeredGridLayoutManager.VERTICAL);
        mLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(adapter);
        Continue=findViewById(R.id.Continue);
        Continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),AddPhotos.class));
            }
        });


    }
    private void dummyData() {
        Titles cc=new Titles("Travelling");
        list.add(cc);
        cc=new Titles("Skating");
        list.add(cc);
        cc=new Titles("Blogging");
        list.add(cc);
        cc=new Titles("Foodie");
        list.add(cc);
        cc=new Titles("Musician");
        list.add(cc);
        cc=new Titles("Tea");
        list.add(cc);
        cc=new Titles("Coffee");
        list.add(cc);
        cc=new Titles("Hiking");
        list.add(cc);
        adapter = new SimpleAdapter(list);
        adapter.notifyDataSetChanged();
    }
}