package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.View;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.khieuware.datingapp.ActivityClass.SignInActivity;
import com.khieuware.datingapp.BaseUrl;
import com.khieuware.datingapp.Fragments.ChatFragment;
import com.khieuware.datingapp.Fragments.HomeFragment;
import com.khieuware.datingapp.Fragments.ProfileFragment;
import com.khieuware.datingapp.Fragments.SwipeFragment;
import com.khieuware.datingapp.Models.UserModel;
import com.khieuware.datingapp.R;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;

import androidx.annotation.NonNull;

import com.google.android.material.snackbar.Snackbar;

import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.khieuware.datingapp.prefrence.SharedPrefManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


import de.hdodenhof.circleimageview.CircleImageView;

public class HomePage extends AppCompatActivity {

    private static final String TAG = HomePage.class.getSimpleName();

    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;
    private FusedLocationProviderClient mFusedLocationClient;


    protected Location mLastLocation;

    private String latitude, longitude;
    int userid;
    CircleImageView hommee, profile, chats;
    SharedPrefManager sharedPrefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        init();


    }

    private void init() {
        loadFragment(new HomeFragment());
    }

    private void loadFragment(Fragment fragment) {
        this.getSupportFragmentManager().beginTransaction()
                .replace(R.id.contentPanel, fragment)
                .commitAllowingStateLoss();
    }
}