package com.khieuware.datingapp.ActivityClass;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.appbar.AppBarLayout;
import com.khieuware.datingapp.Activity.AppSettings;
import com.khieuware.datingapp.Activity.BasicInfo1;
import com.khieuware.datingapp.BaseUrl;
import com.khieuware.datingapp.Fragments.ProfileFragment;
import com.khieuware.datingapp.Models.UserModel;
import com.khieuware.datingapp.R;
import com.khieuware.datingapp.prefrence.SharedPrefManager;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class OTPVerifyActivity extends AppCompatActivity {
    EditText etOtp;
    LinearLayout btnVerifyOtp;
    String strOtp,getOtp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_t_p_verify);
        etOtp = findViewById(R.id.etOtp);
        btnVerifyOtp = findViewById(R.id.btnVerifyOtp);
        UserModel userModel= SharedPrefManager.getInstance(this).getUser();
        getOtp=userModel.getMobile();
        btnVerifyOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              strOtp=etOtp.getText().toString();
                UserVerifyOTP();
            }
        });
    }

    private void UserVerifyOTP() {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, BaseUrl.VERIFYOTP,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            if (jsonObject.getBoolean("responce")){
                                Toast.makeText(OTPVerifyActivity.this,jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(OTPVerifyActivity.this, BasicInfo1.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }else {
                                Toast.makeText(OTPVerifyActivity.this,jsonObject.getString("message"), Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(OTPVerifyActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("mobile",getOtp);
                params.put("otp",strOtp);
                return params;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}