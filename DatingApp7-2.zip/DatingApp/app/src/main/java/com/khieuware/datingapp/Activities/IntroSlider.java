package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.khieuware.datingapp.Adapters.CenterZoomLayoutManager;
import com.khieuware.datingapp.Adapters.SliderImage;
import com.khieuware.datingapp.Models.Image;
import com.khieuware.datingapp.R;

import java.util.ArrayList;
import java.util.List;

public class IntroSlider extends AppCompatActivity {

    RecyclerView recyclerView;
    SliderImage adapter;
    List<Image>imglist=new ArrayList<>();
    TextView skip; LinearLayout next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro_slider);
        init();

    }

    private void dummyData() {
        Image cc=new Image(R.drawable.a1);
        imglist.add(cc);
        cc=new Image(R.drawable.a2);
        imglist.add(cc);
        cc=new Image(R.drawable.a3);
        imglist.add(cc);
        cc=new Image(R.drawable.a4);
        imglist.add(cc);
        cc=new Image(R.drawable.images1);
        imglist.add(cc);
        cc=new Image(R.drawable.images3);
        imglist.add(cc);


        adapter = new SliderImage(imglist);
        adapter.notifyDataSetChanged();
    }


    private void init() {
        skip=findViewById(R.id.skip);
        next=findViewById(R.id.next);
        recyclerView=findViewById(R.id.recyclerview);
        dummyData();
        recyclerView.setLayoutManager(new CenterZoomLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL,false));
        recyclerView.setAdapter(adapter);

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),Login.class));
            }
        });
    }



}