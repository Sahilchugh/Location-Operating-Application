package com.khieuware.datingapp.ActivityClass;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.khieuware.datingapp.BaseUrl;
import com.khieuware.datingapp.Models.UserModel;
import com.khieuware.datingapp.R;
import com.khieuware.datingapp.prefrence.SharedPrefManager;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {
    EditText etName,etEmail, etMob, etPass, etRePass;
    LinearLayout btnSignUp;
    TextView txtLogin;
    String strName,strEmail,strMobile,strPass,strRePass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        init();
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterUser();


            }
        });
        txtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SignUpActivity.this,SignInActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }
    private void init() {
        etName = findViewById(R.id.etName);
        etEmail=findViewById(R.id.etEmail);
        etMob = findViewById(R.id.etMob);
        etPass = findViewById(R.id.etPass);
        etRePass = findViewById(R.id.etRePass);
        btnSignUp = findViewById(R.id.btnSignUp);
        txtLogin = findViewById(R.id.txtLogin);

    }
    private void RegisterUser() {
        strName=etName.getText().toString();
        strEmail=etEmail.getText().toString();
        strMobile=etMob.getText().toString();
        strPass=etPass.getText().toString();
        strRePass=etRePass.getText().toString();
        if (TextUtils.isEmpty(strName)){
            etName.setError("Please Enter  Username");
            etName.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(strEmail)){
            etEmail.setError("Please Enter Email");
            etEmail.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(strMobile)){
            etMob.setError("Please Enter Mobile");
            etMob.requestFocus();
            return;
        }if (TextUtils.isEmpty(strPass)){
            etPass.setError("Please Enter Password");
            etPass.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(strPass)){
            etPass.setError("Please Enter Re Password");
            etPass.requestFocus();
            return;
        }

        StringRequest stringRequest=new StringRequest(Request.Method.POST, BaseUrl.SIGN_UP,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONObject object=jsonObject.getJSONObject("user_data");
                            UserModel model=new UserModel(
                                    object.getInt("id"),
                                    object.getString("name"),
                                    object.getString("email"),
                                    object.getString("mobile"));
                            SharedPrefManager.getInstance(getApplicationContext()).userLogin(model);
                          //  finish();

                            if (jsonObject.getBoolean("responce")){
                                Toast.makeText(SignUpActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                               /* Intent intent=new Intent(SignUpActivity.this,OTPVerifyActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);*/
                                UserSendOTP();

                            }else {
                                Toast.makeText(SignUpActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("name",strName);
                params.put("email",strEmail);
                params.put("mobile",strMobile);
                params.put("password",strPass);
                return params;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void UserSendOTP() {
        StringRequest stringRequest=new StringRequest(Request.Method.POST,BaseUrl.SendOTP,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            if (jsonObject.getBoolean("responce")){
                                Toast.makeText(SignUpActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                              Intent intent=new Intent(SignUpActivity.this,OTPVerifyActivity.class);
                              intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                              startActivity(intent);
                                finish();
                            }else {
                                Toast.makeText(SignUpActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(SignUpActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params=new HashMap<>();
                params.put("mobile",strMobile);
                return params;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

}