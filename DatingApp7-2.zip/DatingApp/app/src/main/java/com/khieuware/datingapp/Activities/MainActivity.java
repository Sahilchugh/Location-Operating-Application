package com.khieuware.datingapp.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.khieuware.datingapp.Fragments.ChatFragment;
import com.khieuware.datingapp.Fragments.FavouritesFragment;
import com.khieuware.datingapp.Fragments.HomeFragment;
import com.khieuware.datingapp.Fragments.ProfileFragment;
import com.khieuware.datingapp.R;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    BottomNavigationView bottomNavigationView;
    FloatingActionButton fab;
/*
    private BottomNavBar.OnBottomNavigationListener mOnBottomNavItemSelectedListener =
            new BottomNavBar.OnBottomNavigationListener() {
                @Override
                public boolean onNavigationItemSelected(MenuItem menuItem) {
                    switch (menuItem.getItemId()){
                        case R.id.navigation_home:
                            mTextMessage.setText(R.string.title_home);
                            return true;
                        case R.id.navigation_payment:
                            mTextMessage.setText(R.string.title_payment);
                            return true;
                        case R.id.navigation_new_cart:
                            mTextMessage.setText(R.string.title_new_cart);
                            return true;
                        case R.id.navigation_dashboard:
                            mTextMessage.setText(R.string.title_dashboard);
                            return true;
                        case R.id.navigation_notifications:
                            mTextMessage.setText(R.string.title_notifications);
                            return true;
                    }
                    return false;
                }
            };
*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomNavigationView=findViewById(R.id.bottombar);
//        BottomNavBar bottomNavView = findViewById(R.id.bottom_nav_view);
//        bottomNavView.setBottomNavigationListener(mOnBottomNavItemSelectedListener);
     //  bottomNavigationView.setBackground(null);
        fab=findViewById(R.id.fab);


        initComponent();
        loadFragment(new HomeFragment());
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HomeFragment trending_fragment = new HomeFragment();
                FragmentManager manager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = manager.beginTransaction();
                fragmentTransaction.replace(R.id.contentPanel, trending_fragment);
                fragmentTransaction.commit();

            }
        });
          bottomNavigationView.setBackgroundColor((R.drawable.btn_gradient));

    }
    private void loadFragment(Fragment fragment) {
        this.getSupportFragmentManager().beginTransaction()
                .replace(R.id.contentPanel, fragment)
                .commitAllowingStateLoss();
    }

    private void initComponent() {
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    loadFragment(new HomeFragment());

//                        HomeeeFragment appNewsHome1Fragment = new HomeeeFragment();
//                        FragmentManager manager = getSupportFragmentManager();
//                        FragmentTransaction transaction = manager.beginTransaction();
//                        transaction.replace(R.id.contentPanel, appNewsHome1Fragment);
//                        transaction.commit();
                    return true;
                case R.id.navigation_notification:
                    loadFragment(new FavouritesFragment());

                    return true;

                case R.id.navigation_chat:
                    loadFragment(new ChatFragment());
                    return true;

                case R.id.navigation_profile:
                    loadFragment(new ProfileFragment());

                    return true;
            }
            return false;
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}