package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.khieuware.datingapp.R;

public class WeMatched extends AppCompatActivity {

    LinearLayout btnplayGame;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_we_matched);

        init();
    }

    private void init() {
        btnplayGame=findViewById(R.id.btnplayGame);
        btnplayGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), LetsPlay.class));

            }
        });

    }
}