package com.khieuware.datingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.khieuware.datingapp.R;

public class ForgotPassword extends AppCompatActivity {

    EditText etEmail;
    LinearLayout btnSendOtp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password2);
        init();
    }

    private void init() {
        etEmail=findViewById(R.id.etEmail);
        btnSendOtp=findViewById(R.id.btnSendOtp);

        btnSendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), OtpCode.class));
                finish();
            }
        });

    }
}