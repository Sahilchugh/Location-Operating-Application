package com.khieuware.datingapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.Volley;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.firebase.FirebaseApp;
import com.khieuware.datingapp.Extra.CustomVolleyJsonRequest;
import com.khieuware.datingapp.Extra.Session_management;
import com.khieuware.datingapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.khieuware.datingapp.BaseUrl.LOGIN;

public class Login extends AppCompatActivity {


    ProgressDialog progressDialog;
    TextView more,trouble;
    Animation animSlideUp;
    LinearLayout OtherLogins,loginPhone,loginFb,loginGoogle;
    LoginButton loginButton;
    private CallbackManager cbm;
    private GoogleSignInClient mGoogleSignInClient;
    private static final int RC_SIGN_IN = 9001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_login);
        cbm = CallbackManager.Factory.create();
        init();
    }

    private void init() {
        printHashKey(getApplicationContext());
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

//        mApiClient = new GoogleApiClient.Builder(this).enableAutoManage(this, this).addApi(Auth.GOOGLE_SIGN_IN_API, gso).build();


        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        try {
            @SuppressLint("PackageManagerGetSignatures")
            PackageInfo info = getPackageManager().getPackageInfo("com.memuzin.user", PackageManager.GET_SIGNATURES);
            for (android.content.pm.Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String sign = Base64.encodeToString(md.digest(), Base64.DEFAULT);
                System.out.println("TAG" + " " + sign);
                Log.i("TAG", sign);
            }
        } catch (PackageManager.NameNotFoundException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Loading..");
        progressDialog.setCancelable(true);
        more=findViewById(R.id.more);
        OtherLogins=findViewById(R.id.OtherLogins);
        loginPhone=findViewById(R.id.loginPhone);
        loginFb=findViewById(R.id.loginfb);
        loginGoogle=findViewById(R.id.loginGoogle);
        trouble=findViewById(R.id.trouble);
        OtherLogins.setVisibility(View.GONE);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animSlideUp = AnimationUtils.loadAnimation(getApplicationContext(),
                        R.anim.slide_up);

                more.setVisibility(View.GONE);
                OtherLogins.startAnimation(animSlideUp);

                OtherLogins.setVisibility(View.VISIBLE);

            }
        });

        loginPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),LoginwithPassword.class));
            }
        });
        loginFb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fbLogin();
            }
        });
        loginGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();
            }
        });

        trouble.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),NewRegister.class));
            }
        });
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void fbLogin() {
      /*  LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("email", "public_profile"));
      //  LoginManager.getInstance().registerCallback(cbm,
                cbm = CallbackManager.Factory.create();

        LoginManager.getInstance().registerCallback(cbm, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // App code
                //loginResult.getAccessToken();
                //loginResult.getRecentlyDeniedPermissions()
                //loginResult.getRecentlyGrantedPermissions()
                getUserProfile(AccessToken.getCurrentAccessToken());
                boolean loggedIn = AccessToken.getCurrentAccessToken() == null;
                Log.d("API123", loggedIn + " ??");

            }

            @Override
            public void onCancel() {
                // App code
            }

            @Override
            public void onError(FacebookException exception) {
                // App code
            }
        });*/
        loginButton.performClick();
        List< String > permissionNeeds = Arrays.asList("user_photos", "email",
                "user_birthday", "public_profile", "AccessToken");
        loginButton.registerCallback(cbm,
                new FacebookCallback<LoginResult>() {@Override
                public void onSuccess(LoginResult loginResult) {

                    //  System.out.println("onSuccess");

                    String accessToken = loginResult.getAccessToken()
                            .getToken();
                    Log.i("accessToken", accessToken);

                    GraphRequest request = GraphRequest.newMeRequest(
                            loginResult.getAccessToken(),
                            new GraphRequest.GraphJSONObjectCallback() {@Override
                            public void onCompleted(JSONObject json,
                                                    GraphResponse response) {

                                Log.i("LoginActivity",
                                        response.toString());
                               /* try {
                                    String id = object.getString("id");
                                    try {
                                        URL profile_pic = new URL(
                                                "http://graph.facebook.com/" + id + "/picture?type=large");
                                        Log.i("profile_pic",
                                                profile_pic + "");

                                    } catch (MalformedURLException e) {
                                        e.printStackTrace();
                                    }

                                    String name = object.getString("name");
                                    String  email = object.getString("email");
                                    String  gender = object.getString("gender");
                                    String  birthday = object.getString("birthday");
                                    Log.d("nme", name);
                                    // Log.d("email", email);
                                    //  Log.d("gender", gender);
                                    //  Log.d("birthday", birthday);
                                    makeSocialLogin(email,"true",name);
                                    if(email!=null&& email.length()>0){
                                        makeSocialLogin(email,"true",name);
                                    }*/
                                try {
                                    if (response.getError() != null) {

                                        Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_LONG).show();
                                    } else {
                                        String name_1 = json.getString("name");

                                        String uid = json.getString("id");
                                        //  Toast.makeText(getApplicationContext(),"Welcome " +name_1, Toast.LENGTH_LONG).show();

                                        String email = "no email";
                                        if (json.has("email")) {
                                            email = json.getString("email");
                                            if (email != null && email.length() > 0) {
                                                makeSocialLogin(name_1, email, "1",uid);
                                            }
                                        }else {
                                            makeSocialLogin(name_1, email, "1",uid);
                                        }}

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            });
                    Bundle parameters = new Bundle();
                    parameters.putString("fields",
                            "id,name,email,gender, birthday");
                    request.setParameters(parameters);
                    request.executeAsync();
                }

                    @Override
                    public void onCancel() {
                        //  System.out.println("onCancel");
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // System.out.println("onError");
                        Log.v("LoginActivity", exception.toString());
                    }
                });
    }
    private void makeSocialLogin(final String displayName, final String email, final String type,final String id) {

        String tag_json_obj = "json_login_req";
        Map<String, String> params = new HashMap<String, String>();
        params.put("userid",email);
        params.put("password", "qwertyui");
        params.put("social_login",type);
        params.put("facebook_username",id);

        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.POST,
                LOGIN, params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("awsedrftgyhj", response.toString());

                try {
                    boolean status = response.getBoolean("responce");
                    if (status) {
                        JSONObject obj = response.getJSONObject("data");
                        String user_id = obj.getString("user_id");
                        String user_fullname = obj.getString("user_fullname");
                        String user_email = obj.getString("user_email");
                        String user_phone = obj.getString("user_phone");
                        String user_image = obj.getString("user_image");
                        String wallet_ammount = obj.getString("wallet");
                        String reward_points = obj.getString("rewards");

                        Session_management sessionManagement = new Session_management(getApplicationContext());
                        //  sessionManagement.createLoginSession2(user_id, user_email, user_fullname, user_phone, user_image, wallet_ammount, reward_points, "", "", "", "", "");
                        sessionManagement.createLoginSession(user_id, user_email, user_fullname, user_phone, user_image, wallet_ammount, reward_points, "", "", "", "", "");

//                        MyFirebaseRegister myFirebaseRegister = new MyFirebaseRegister(getApplicationContext());
//                        myFirebaseRegister.RegisterUser(user_id);
//                        btn_continue.setEnabled(false);
                        progressDialog.dismiss();
//                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
//                        //   i.putExtra("mobile", user_phone);
//                        startActivity(i);
                        finish();

                    } else {
                        Intent i = new Intent(getApplicationContext(), NewRegister.class);
                        i.putExtra("name", displayName);
                        i.putExtra("email", email);
                        i.putExtra("uId", id);
                        startActivity(i);
                        finish();
                        progressDialog.dismiss();
                       // btn_continue.setEnabled(true);
                        String error = response.getString("error");
                        Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    progressDialog.hide();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.hide();
                VolleyLog.d("TAG", "Error: " + error.getMessage());
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                  //  Toast.makeText(getApplicationContext(), Login.this.getResources().getString(R.string.connection_time_out), Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Adding request to request queue
        jsonObjReq.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 90000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 0;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(jsonObjReq);
        // AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }
    private void makeSocialGmailLogin(final String displayName, final String email, final String type) {

        String tag_json_obj = "json_login_req";
        Map<String, String> params = new HashMap<String, String>();
        params.put("userid",email);
        params.put("password", "qwertyui");
        params.put("social_login",type);

        CustomVolleyJsonRequest jsonObjReq = new CustomVolleyJsonRequest(Request.Method.POST,
                LOGIN, params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("awsedrftgyhj", response.toString());

                try {
                    boolean status = response.getBoolean("responce");
                    if (status) {
                        JSONObject obj = response.getJSONObject("data");
                        String user_id = obj.getString("user_id");
                        String user_fullname = obj.getString("user_fullname");
                        String user_email = obj.getString("user_email");
                        String user_phone = obj.getString("user_phone");
                        String user_image = obj.getString("user_image");
                        String wallet_ammount = obj.getString("wallet");
                        String reward_points = obj.getString("rewards");

                        Session_management sessionManagement = new Session_management(getApplicationContext());
                        //  sessionManagement.createLoginSession2(user_id, user_email, user_fullname, user_phone, user_image, wallet_ammount, reward_points, "", "", "", "", "");
                        sessionManagement.createLoginSession(user_id, user_email, user_fullname, user_phone, user_image, wallet_ammount, reward_points, "", "", "", "", "");

//                        MyFirebaseRegister myFirebaseRegister = new MyFirebaseRegister(getApplicationContext());
//                        myFirebaseRegister.RegisterUser(user_id);
//                        btn_continue.setEnabled(false);
                        progressDialog.dismiss();
                       Intent i = new Intent(getApplicationContext(), Location.class);
                        //   i.putExtra("mobile", user_phone);
                        startActivity(i);
                        finish();

                    } else {
                        Intent i = new Intent(getApplicationContext(), NewRegister.class);
                        i.putExtra("name", displayName);
                        i.putExtra("email", email);
                       // i.putExtra("uId", id);
                        startActivity(i);
                        finish();
                        progressDialog.dismiss();
                        // btn_continue.setEnabled(true);
                        String error = response.getString("error");
                        Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    progressDialog.hide();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.hide();
                VolleyLog.d("TAG", "Error: " + error.getMessage());
                if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                    //  Toast.makeText(getApplicationContext(), Login.this.getResources().getString(R.string.connection_time_out), Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Adding request to request queue
        jsonObjReq.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 90000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 0;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(jsonObjReq);
        // AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }


    public static void printHashKey(Context pContext) {
        try {
            PackageInfo info = pContext.getPackageManager().getPackageInfo(pContext.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String hashKey = new String(Base64.encode(md.digest(), 0));
                Log.d("dfgtyui","printHashKey() Hash Key: " + hashKey);
            }
        } catch (NoSuchAlgorithmException e) {
            Log.e("TAG", "printHashKey()", e);//eae1/NvBimh/n+PoCEvuQbJ/zlA=
        } catch (Exception e) {                                    ///yiIx4gbAGNcebt9CB+gDaZ0+tA=
            Log.e("TAG", "printHashKey()", e);
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {

            GoogleSignInResult googleSignInResult = Auth.GoogleSignInApi.getSignInResultFromIntent(data);

            GoogleSignInAccount account = googleSignInResult.getSignInAccount();
            if (account != null) {
                Log.i("TAG", "" + account.getDisplayName());
                handleSignInResult(googleSignInResult);
            }
        } else {
            cbm.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void handleSignInResult(GoogleSignInResult result) {

        Log.d("TAG", "handleSignInResult:" + result.isSuccess());
        try {
            if (result.isSuccess()) {
                // Signed in successfully, show authenticated UI.
                GoogleSignInAccount acct = result.getSignInAccount();
                assert acct != null;
                Log.e("TAG", "display name: " + acct.getDisplayName());
                acct.getEmail();
                acct.getPhotoUrl();
                Log.e("TAG", "display Email: " + acct.getEmail());
                Log.e("TAG", "display Photo: " + acct.getPhotoUrl());

                if (acct.getEmail()!=null && acct.getEmail().length()>0){
                    makeSocialGmailLogin(acct.getDisplayName(),acct.getEmail(),"1");
                }
            }
        } catch (Exception e) {
            Log.i("Exception is", e.toString());

        }

    }

}